library(testthat)
library(AMKAT)

test_check("AMKAT")
